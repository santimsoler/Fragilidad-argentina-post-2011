# ==============================================================================
# SCRIPT FINAL MAESTRO - REPLICACIÓN ÍNTEGRA Y CONSOLIDADA
# ==============================================================================
library(ggplot2)
library(dplyr)
library(tidyr)

# ==============================================================================
# 1. CARGA DE BASE
# ==============================================================================

setwd("C:/Users/FARAH MOHALEM/Documents/MAESTRIA/FINANZAS INTERNACIONALES/")

df_final <- read.csv(
  "base_final.csv",
  stringsAsFactors = FALSE
)

# 2. PROCESAMIENTO: Estandarización Z-Score (MANTENIENDO TU LÓGICA ORIGINAL)
df_final <- df_final %>%
  group_by(iso3c) %>%
  mutate(
    # Estandarizar componentes para EMPI Simple
    std_ner = (d_ln_ner - mean(d_ln_ner, na.rm=TRUE)) / sd(d_ln_ner, na.rm=TRUE),
    std_res = (d_ln_res - mean(d_ln_res, na.rm=TRUE)) / sd(d_ln_res, na.rm=TRUE),
    empi_simple_std = (std_ner - std_res - mean(std_ner - std_res, na.rm=TRUE)) / sd(std_ner - std_res, na.rm=TRUE),
    
    # Estandarizar el EMPI Robust original
    empi_rob_std = (empi - mean(empi, na.rm=TRUE)) / sd(empi, na.rm=TRUE),
    
    # Empalme final: si no hay robusto, usamos el simple estandarizado
    empi_grafico = ifelse(is.na(empi_rob_std), empi_simple_std, empi_rob_std)
  ) %>%
  ungroup()

# ------------------------------------------------------------------------------
# A. CUADRO DE VOLATILIDAD
# ------------------------------------------------------------------------------
tabla_volatilidad <- df_final %>%
  filter(!is.na(empi_grafico)) %>%
  group_by(iso3c) %>%
  summarise(
    Volatilidad_EMPI = sd(empi_grafico, na.rm = TRUE),
    Presion_Media = mean(empi_grafico, na.rm = TRUE)
  ) %>%
  arrange(desc(Volatilidad_EMPI))

print(as.data.frame(tabla_volatilidad))

# ------------------------------------------------------------------------------
# B. GRÁFICO 1: Argentina (Retenciones vs EMPI)
# ------------------------------------------------------------------------------
arg_data <- df_final %>% filter(iso3c == "ARG")
ggplot(arg_data, aes(x = year)) +
  geom_line(aes(y = tax_rate_eff, color = "Retenciones"), size = 1.2) +
  geom_line(aes(y = empi_grafico * 5, color = "EMPI"), size = 1.2) +
  scale_y_continuous(sec.axis = sec_axis(~./5, name = "EMPI (Z-Score)")) +
  theme_minimal() +
  labs(title = "Argentina: Política Comercial vs. Estrés Cambiario", x = "Año", y = "Retenciones (%)")

# ------------------------------------------------------------------------------
# C. GRÁFICO 2: Comparativa Regional
# ------------------------------------------------------------------------------
paises <- c("ARG", "BRA", "CHL", "COL", "URY", "PRY")
ggplot(df_final %>% filter(iso3c %in% paises), aes(x = year, y = empi_grafico, color = iso3c)) +
  geom_line(aes(size = (iso3c == "ARG"), alpha = (iso3c == "ARG"))) +
  scale_size_manual(values = c("TRUE" = 1.5, "FALSE" = 0.5)) +
  scale_alpha_manual(values = c("TRUE" = 1, "FALSE" = 0.5)) +
  theme_minimal() + labs(title = "Comparativa Regional: EMPI Z-Score")

# ------------------------------------------------------------------------------
# D. GRÁFICO 3: Volatilidad Barras
# ------------------------------------------------------------------------------
df_final %>%
  filter(iso3c %in% paises) %>%
  mutate(periodo = ifelse(year <= 2010, "Pre-2011", "Post-2011")) %>%
  group_by(iso3c, periodo) %>%
  summarise(volatilidad = sd(empi_grafico, na.rm = TRUE)) %>%
  ggplot(aes(x = iso3c, y = volatilidad, fill = periodo)) +
  geom_bar(stat = "identity", position = "dodge") + theme_minimal() +
  labs(title = "Volatilidad Cambiaria", y = "Desvío Estándar (Z-Score)")

# ------------------------------------------------------------------------------
# E. ANÁLISIS DE "STOP AND GO": CHOQUES EMPI Y PIB
# ------------------------------------------------------------------------------
df_stop_go <- df_final %>%
  filter(iso3c == "ARG") %>%
  mutate(
    es_shock = ifelse(empi_grafico > 1.5, 1, 0),
    crecimiento_t = growth,
    crecimiento_t1 = dplyr::lead(growth, 1)
  )

resumen_stop_go <- df_stop_go %>%
  group_by(es_shock) %>%
  summarise(
    Media_PIB = mean(crecimiento_t, na.rm=TRUE),
    Media_PIB_t1 = mean(crecimiento_t1, na.rm=TRUE),
    Volatilidad_PIB = sd(crecimiento_t, na.rm=TRUE),
    n = n()
  )

ggplot(df_stop_go, aes(x = factor(es_shock), y = growth, fill = factor(es_shock))) +
  geom_boxplot() + theme_minimal() +
  scale_fill_manual(values = c("0" = "skyblue", "1" = "firebrick"), labels = c("Normal", "Shock EMPI")) +
  labs(title = "El efecto del 'Stop': Distribución del PIB", x = "Condición", y = "Crecimiento del PIB (%)")

print(resumen_stop_go)

# ------------------------------------------------------------------------------
# F. EXPORTACIÓN FINAL
# ------------------------------------------------------------------------------
write.csv(df_final, "base_maestra_TESIS_FINAL_COMPLETA_EJECUTADA.csv", row.names = FALSE)