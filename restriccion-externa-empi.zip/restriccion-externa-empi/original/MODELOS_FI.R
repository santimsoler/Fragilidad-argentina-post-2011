# ==============================================================================
# 0. LIBRERÍAS
# ==============================================================================

library(dplyr)
library(tidyr)
library(plm)
library(lmtest)
library(car)
library(sandwich)
library(zoo)
library(vars)
library(Synth)
library(strucchange)

# ==============================================================================
# 1. CARGA DE BASE
# ==============================================================================

setwd("C:/Users/FARAH MOHALEM/Documents/MAESTRIA/FINANZAS INTERNACIONALES/")

df_final <- read.csv(
  "base_final.csv",
  stringsAsFactors = FALSE
)

# ==============================================================================
# 2. PANEL BASE
# ==============================================================================

df_panel <- df_final %>%
  dplyr::filter(year >= 1995) %>%
  dplyr::select(
    iso3c,
    year,
    empi_robust,
    empi,
    tot_index,
    fed_rate,
    current_account,
    fiscal_primario,
    vix,
    gdp_real,
    openness,
    brecha_anual,
    dexmedia
  ) %>%
  dplyr::arrange(iso3c, year)

df_panel <- df_panel %>%
  dplyr::rename(costo_financiero_ext = fed_rate)
# ==============================================================================
# 3. LIMPIEZA
# ==============================================================================

df_panel <- df_panel %>%
  
  mutate(
    
    dexmedia =
      ifelse(is.na(dexmedia), 0, dexmedia),
    
    # ❗ NO convertir NA a 0 en brecha (esto era problemático)
    brecha_anual =
      ifelse(is.na(brecha_anual), NA, brecha_anual)
    
  )

# Pon esto justo después del punto 3
df_panel$empi_final <- df_panel$empi_robust

# ==============================================================================
# 4. ÍNDICE DE RENTABILIDAD EXPORTADORA
# ==============================================================================

df_panel <- df_panel %>%
  
  mutate(
    
    rentabilidad_exportadora =
      tot_index * (1 - dexmedia) * (1 / brecha_anual)
    
  )

# ==============================================================================
# 5. LOG DEL ÍNDICE
# ==============================================================================

df_panel <- df_panel %>%
  
  mutate(
    
    rentabilidad_exportadora = ifelse(
      is.infinite(rentabilidad_exportadora) |
        rentabilidad_exportadora <= 0,
      NA,
      rentabilidad_exportadora
    ),
    
    ln_rentabilidad = log(rentabilidad_exportadora)
    
  )

# ==============================================================================
# 6. VARIABLES ESTRUCTURALES (AJUSTADAS A CORTE 2011)
# ==============================================================================

df_panel <- df_panel %>%
  mutate(
    # Cambiamos el corte a 2011 para que coincida con el Control Sintético
    post2011 = ifelse(year >= 2011, 1, 0),
    
    ARG = ifelse(iso3c == "ARG", 1, 0),
    
    # Esta variable es la que usaremos en la fórmula del modelo
    ARG_post = ARG * post2011
  )
# ==============================================================================
# 7. PANEL
# ==============================================================================

pdata <- pdata.frame(df_panel, index = c("iso3c", "year"))

# ==============================================================================
# 9. DIAGNÓSTICOS
# ==============================================================================

cat("\n=====================================\n")
cat("BASE PREPARADA\n")
cat("=====================================\n")

cat("Observaciones:", nrow(df_panel), "\n")
cat("Países:", length(unique(df_panel$iso3c)), "\n")
cat("Años:", min(df_panel$year), "-", max(df_panel$year), "\n")

cat("\nResumen índice de rentabilidad\n")
print(summary(df_panel$rentabilidad_exportadora))

cat("\nResumen log rentabilidad\n")
print(summary(df_panel$ln_rentabilidad))

cat("\nCorrelaciones principales\n")

print(
  
  cor(
    
    df_panel %>%
      dplyr::select(
        tot_index,
        brecha_anual,
        dexmedia,
        rentabilidad_exportadora
      ),
    
    use = "pairwise.complete.obs"
    
  )
  
)

cat("\nBase preparada correctamente.\n")

select <- dplyr::select
filter <- dplyr::filter
lag <- dplyr::lag
rename <- dplyr::rename
arrange <- dplyr::arrange
mutate <- dplyr::mutate
summarise <- dplyr::summarise
############################################################
# 10. MODELO ECONOMÉTRICO COMPLETO (VERSIÓN LIMPIA)
# BLOQUE 1/6
# PREPARACIÓN + REZAGOS + VARIABLES DINÁMICAS
############################################################

library(plm)
library(lmtest)
library(sandwich)
library(dplyr)
library(zoo)
library(strucchange)
library(tseries)

############################################################
# PREPARACIÓN BASE
############################################################

df_panel <- df_panel %>%
  arrange(iso3c, year) %>%
  mutate(
    ln_gdp = log(gdp_real),
    
    # BREAKS ESTRUCTURALES (HIPÓTESIS CENTRAL)
    post2011 = ifelse(year >= 2011, 1, 0),
    post2003 = ifelse(year >= 2003, 1, 0),
    
    # REGÍMENES ECONÓMICOS
    regime = case_when(
      year < 2003 ~ "pre_2003",
      year <= 2011 ~ "boom_2003_2011",
      TRUE ~ "post_2011"
    ),
    
    # VARIABLE DE STRESS EXTERNO (MEJORA ANALÍTICA)
    stress_ca = abs(current_account),
    stress_high = ifelse(
      stress_ca > quantile(stress_ca, 0.75, na.rm = TRUE),
      1, 0
    ),
    
    # INTERACCIONES ESTRUCTURALES (CLAVE PARA TU HIPÓTESIS)
    boom_0311 = ifelse(year >= 2003 & year <= 2011, 1, 0),
    post2011_rent = post2011 * ln_rentabilidad,
    boom_rent = boom_0311 * ln_rentabilidad
  )

############################################################
# PASAR A PANEL (FORMATO plm)
############################################################

panel <- pdata.frame(
  df_panel,
  index = c("iso3c", "year"),
  drop.index = TRUE
)

############################################################
# REZAGOS CONSISTENTES (POR PAÍS)
############################################################

panel$empi_l1 <- plm::lag(panel$empi, 1)
panel$empi_l2 <- plm::lag(panel$empi, 2)

panel$L1_rent <- plm::lag(panel$ln_rentabilidad, 1)
panel$L2_rent <- plm::lag(panel$ln_rentabilidad, 2)
panel$L3_rent <- plm::lag(panel$ln_rentabilidad, 3)

############################################################
# RENTABILIDAD PERSISTENTE (SUAVIZADO ROBUSTO)
############################################################

df_panel <- df_panel %>%
  arrange(iso3c, year) %>%
  group_by(iso3c) %>%
  mutate(
    rent_ma3 = zoo::rollapply(
      ln_rentabilidad,
      width = 3,
      FUN = mean,
      align = "right",
      fill = NA,
      na.rm = TRUE
    )
  ) %>%
  ungroup()

############################################################
# ACTUALIZAR PANEL FINAL
############################################################

panel <- pdata.frame(
  df_panel,
  index = c("iso3c", "year")
)

############################################################
# BLOQUE 2/6
# LAGS CONSISTENTES + TRANSFORMACIONES DINÁMICAS
############################################################

# IMPORTANTE:
# Todo se construye desde df_panel (NO desde pdata.frame)
# para evitar bugs de índices rotos

df_panel <- df_panel %>%
  arrange(iso3c, year) %>%
  group_by(iso3c) %>%
  mutate(
    
    ########################################################
    # DEPENDIENTE DINÁMICA
    ########################################################
    empi_l1 = dplyr::lag(empi, 1),
    empi_l2 = dplyr::lag(empi, 2),
    
    ########################################################
    # RENTABILIDAD (PERSISTENCIA MULTI-LAG)
    ########################################################
    L1_rent = dplyr::lag(ln_rentabilidad, 1),
    L2_rent = dplyr::lag(ln_rentabilidad, 2),
    L3_rent = dplyr::lag(ln_rentabilidad, 3),
    
    ########################################################
    # MACRO FUNDAMENTALS LAGGED
    ########################################################
    gdp_l1 = dplyr::lag(ln_gdp, 1),
    openness_l1 = dplyr::lag(openness, 1),
    ca_l1 = dplyr::lag(current_account, 1),
    
    ########################################################
    # VOLATILIDAD RENTABILIDAD
    ########################################################
    rent_vol = zoo::rollapply(
      ln_rentabilidad,
      width = 3,
      FUN = sd,
      align = "right",
      fill = NA,
      na.rm = TRUE
    )
    
  ) %>%   # 👈 ESTE CIERRE FALTABA (CRÍTICO)
  ungroup()

############################################################
# PASAR A PANEL NUEVAMENTE (CONSISTENTE)
############################################################

panel <- pdata.frame(
  df_panel,
  index = c("iso3c", "year")
)

############################################################
# CHEQUEO RÁPIDO DE ESTRUCTURA
############################################################

cat("\nCHECK PANEL STRUCTURE\n")
print(pdim(panel))

############################################################
# NA DIAGNÓSTICO PANEL
############################################################

na_by_country <- df_panel %>%
  group_by(iso3c) %>%
  summarise(
    empi_na = sum(is.na(empi)),
    rent_na = sum(is.na(L1_rent)),
    total = n()
  )

print(na_by_country)

############################################################
# NA SUMMARY (VARIABLES CLAVE)
############################################################

cat("\nNA SUMMARY (VARIABLES CLAVE)\n")

vars_check <- c("empi", "L1_rent", "L2_rent", "L3_rent")

na_summary <- colSums(
  is.na(df_panel[, vars_check])
)

print(na_summary)

############################################################
# BLOQUE 3/6
# MODELOS FE + DRISCOLL-KRAAY
############################################################

library(plm)
library(lmtest)
library(sandwich)

############################################################
# FUNCIÓN FE LIMPIA (TWOWAY + FALLBACK + ROBUSTEZ)
############################################################

run_fe <- function(formula, data){
  
  # 1) estimación FE twoway
  m <- try(
    plm(
      formula,
      data = data,
      model = "within",
      effect = "twoways"
    ),
    silent = TRUE
  )
  
  # 2) fallback individual si falla twoway
  if(inherits(m, "try-error")){
    m <- plm(
      formula,
      data = data,
      model = "within",
      effect = "individual"
    )
  }
  
  # 3) HAC clustered (baseline)
  cat("\n==============================\n")
  cat("FE MODEL\n")
  cat("==============================\n")
  
  print(
    coeftest(
      m,
      vcov = vcovHC(m, type = "HC1", cluster = "group")
    )
  )
  
  cat("\nR2 within:", summary(m)$r.squared["rsq"], "\n")
  
  return(m)
}

############################################################
# DRISCOLL-KRAAY (ROBUSTO A CD + HETEROCEDASTICIDAD + SERIAL)
############################################################

run_dk <- function(model){
  
  cat("\n==============================\n")
  cat("DRISCOLL-KRAAY SE\n")
  cat("==============================\n")
  
  print(
    coeftest(
      model,
      vcov = vcovSCC(model, type = "HC1", maxlag = 2)
    )
  )
}

############################################################
# MODELO BASE
############################################################

m1 <- run_fe(
  empi ~ L1_rent + ln_gdp + openness,
  df_panel
)

run_dk(m1)

############################################################
# CANAL EXTERNO
############################################################

m2 <- run_fe(
  empi ~ L1_rent * current_account +
    ln_gdp + openness,
  df_panel
)

run_dk(m2)

m2b <- run_fe(
  empi ~ L1_rent * post2011 +
    ln_gdp + openness,
  df_panel
)
run_dk(m2b)


############################################################
# PERSISTENCIA RENTABILIDAD
############################################################

m3 <- run_fe(
  empi ~ L1_rent * stress_high +
    ln_gdp + openness,
  df_panel
)

run_dk(m3)

############################################################
# MODELO DINÁMICO BASE
############################################################

m4 <- run_fe(
  empi ~ empi_l1 +
    L1_rent * post2011 +
    ln_gdp + openness,
  df_panel
)

run_dk(m4)

############################################################
# MODELO COMPLETO
############################################################

m6 <- run_fe(
  empi ~ empi_l1 +
    L1_rent * post2011 * current_account +
    ln_gdp + openness + fiscal_primario +
    brecha_anual,
  df_panel
)

run_dk(m6)

############################################################
# BLOQUE 4/6
# ARELLANO-BOND + SYSTEM GMM (ESTABLE)
############################################################

library(plm)

############################################################
# PRECAUCIÓN ESTRUCTURAL
############################################################
# Con N pequeño (12), hay que:
# - colapsar instrumentos
# - limitar lags
# - evitar sobreidentificación

############################################################
# BLOQUE 4/6
# ARELLANO-BOND (VERSIÓN ESTABLE SIN pgmm BUG)
############################################################

library(plm)
library(dplyr)

############################################################
# DATA LIMPIA (CRÍTICO)
############################################################

gmm_data <- df_panel %>%
  select(iso3c, year, empi, L1_rent, ln_gdp, current_account) %>%
  arrange(iso3c, year) %>%
  na.omit()

gmm_panel <- pdata.frame(
  gmm_data,
  index = c("iso3c", "year")
)

############################################################
# VARIABLES LAG (EXPLÍCITAS)
############################################################

gmm_panel$empi_l1 <- lag(gmm_panel$empi, 1)
gmm_panel$empi_l2 <- lag(gmm_panel$empi, 2)

gmm_panel$empi_l2_iv <- lag(gmm_panel$empi, 2)
gmm_panel$empi_l3_iv <- lag(gmm_panel$empi, 3)

############################################################
# ARELLANO-BOND "MANUAL FE-DIFF APPROX"
############################################################
# Esto replica la idea AB SIN pgmm (estable en plm)

ab_model <- plm(
  empi ~ empi_l1 + L1_rent + ln_gdp + current_account,
  data = gmm_panel,
  model = "within",
  effect = "individual"
)

cat("\n==============================\n")
cat("ARELLANO-BOND APPROX (FE-DYNAMIC)\n")
cat("==============================\n")

print(summary(ab_model))

############################################################
# SYSTEM GMM (VERSIÓN SEGURA: SOLO FE DINÁMICO)
############################################################

sys_model <- plm(
  empi ~ empi_l1 + L1_rent + ln_gdp + current_account,
  data = gmm_panel,
  model = "within",
  effect = "twoways"
)

cat("\n==============================\n")
cat("SYSTEM GMM APPROX (FE TWOWAY DYNAMIC)\n")
cat("==============================\n")

print(summary(sys_model))
############################################################
# BLOQUE 5/6
# BREAKS + ESTACIONARIEDAD + DIAGNÓSTICOS
############################################################

library(strucchange)
library(tseries)
library(plm)
library(dplyr)

############################################################
# 1. CHOW TEST (ARG_POST)
############################################################

m_chow <- plm(
  empi ~ L1_rent * boom_0311 +
    L1_rent * post2011 +
    ln_gdp + current_account,
  data = df_panel,
  model = "within",
  effect = "individual"
)

m_chow2 <- plm(
  empi ~ L1_rent * post2011 + ln_gdp + current_account,
  data = df_panel,
  model = "within",
  effect = "individual"
)

run_dk(m_chow2)

cat("\n==============================\n")
cat("CHOW / STRUCTURAL BREAK (ARG)\n")
cat("==============================\n")

print(summary(m_chow))

# ==============================================================================
# 2. TEST DE BREAKPOINTS (BAI-PERRON)
# ==============================================================================

bp_data <- df_panel %>%
  dplyr::filter(iso3c == "ARG") %>%
  dplyr::arrange(year) %>%
  dplyr::mutate(
    ln_rentabilidad = log1p(rentabilidad_exportadora),
    ln_gdp = log(gdp_real)
  ) %>%
  dplyr::select(
    year,
    empi,
    ln_rentabilidad,
    ln_gdp,
    current_account
  ) %>%
  na.omit()

bp <- strucchange::breakpoints(
  empi ~ ln_rentabilidad + ln_gdp + current_account,
  data = bp_data,
  h = 0.25
)

cat("\n==============================\n")
cat("RESUMEN GENERAL BAI-PERRON\n")
cat("==============================\n")

print(summary(bp))

plot(bp)

#------------------------------------------------------------------------------
# SOLUCIÓN ÓPTIMA (BIC)
#------------------------------------------------------------------------------

cat("\n==============================\n")
cat("QUIEBRES ÓPTIMOS (BIC)\n")
cat("==============================\n")

if (!is.null(bp$breakpoints) && any(!is.na(bp$breakpoints))) {
  
  print(bp_data$year[bp$breakpoints])
  
} else {
  
  cat("No se detectaron quiebres.\n")
  
}

#------------------------------------------------------------------------------
# SOLUCIÓN CON DOS QUIEBRES
#------------------------------------------------------------------------------

cat("\n==============================\n")
cat("SOLUCIÓN FORZADA CON 2 QUIEBRES\n")
cat("==============================\n")

bp2 <- breakpoints(
  empi ~ ln_rentabilidad + ln_gdp + current_account,
  data = bp_data,
  h = 0.20,
  breaks = 2
)

print(summary(bp2))

cat("\nAños de los dos quiebres:\n")
print(bp_data$year[bp2$breakpoints])

plot(bp2)

############################################################
# 3. ESTACIONARIEDAD (PANEL UNIT ROOT TESTS)
############################################################

cat("\n==============================\n")
cat("UNIT ROOT TESTS\n")
cat("==============================\n")

print(
  purtest(
    empi ~ 1,
    data = df_panel,
    index = c("iso3c", "year"),
    test = "levinlin",
    exo = "intercept"
  )
)

print(
  purtest(
    ln_rentabilidad ~ 1,
    data = df_panel,
    index = c("iso3c", "year"),
    test = "ips",
    exo = "intercept"
  )
)

print(
  purtest(
    ln_gdp ~ 1,
    data = df_panel,
    index = c("iso3c", "year"),
    test = "madwu",
    exo = "intercept"
  )
)

############################################################
# 4. CROSS-SECTION DEPENDENCE
############################################################

cat("\n==============================\n")
cat("CROSS-SECTION DEPENDENCE (Pesaran CD)\n")
cat("==============================\n")

print(
  pcdtest(
    m_chow,
    test = "cd"
  )
)

############################################################
# 5. AUTOCORRELATION
############################################################

cat("\n==============================\n")
cat("AUTOCORRELATION (Breusch-Godfrey)\n")
cat("==============================\n")

print(pbgtest(m_chow))

############################################################
# 6. HETEROCEDASTICITY
############################################################

cat("\n==============================\n")
cat("HETEROCEDASTICITY (Breusch-Pagan)\n")
cat("==============================\n")

print(bptest(m_chow))

############################################################
# BLOQUE 6/6
# ROBUSTEZ Y ANÁLISIS COMPLEMENTARIO
############################################################

library(plm)
library(lmtest)
library(sandwich)
library(dplyr)

############################################################
# 1. EFECTOS ALEATORIOS (COMPARACIÓN)
############################################################

modelo_re <- plm(
  empi ~ L1_rent +
    ln_gdp +
    current_account,
  data = df_panel,
  model = "random"
)

cat("\n==============================\n")
cat("MODELO DE EFECTOS ALEATORIOS\n")
cat("==============================\n")

print(summary(modelo_re))

############################################################
# 2. EFECTOS FIJOS (REFERENCIA)
############################################################

modelo_fe <- plm(
  empi ~ L1_rent +
    ln_gdp +
    current_account,
  data = df_panel,
  model = "within"
)

cat("\n==============================\n")
cat("MODELO DE EFECTOS FIJOS\n")
cat("==============================\n")

print(summary(modelo_fe))

############################################################
# 3. HAUSMAN
############################################################

cat("\n==============================\n")
cat("TEST DE HAUSMAN\n")
cat("==============================\n")

print(phtest(modelo_fe, modelo_re))

############################################################
# 4. EFECTOS FIJOS + DRISCOLL-KRAAY
############################################################

cat("\n==============================\n")
cat("EFECTOS FIJOS + DRISCOLL-KRAAY\n")
cat("==============================\n")

print(
  
  coeftest(
    
    modelo_fe,
    
    vcov = vcovSCC(
      modelo_fe,
      type = "HC1"
    )
    
  )
  
)

############################################################
# 5. ELASTICIDAD PARA ARGENTINA
############################################################

modelo_arg <- lm(
  empi ~ L1_rent * current_account,
  data = subset(df_panel, iso3c == "ARG")
)

cat("\n==============================\n")
cat("MODELO SOLO ARGENTINA\n")
cat("==============================\n")

print(summary(modelo_arg))

############################################################
# 6. MATRIZ DE CORRELACIONES
############################################################

cat("\n==============================\n")
cat("CORRELACIONES\n")
cat("==============================\n")

print(
  
  cor(
    
    df_panel %>%
      dplyr::select(
        empi,
        L1_rent,
        ln_gdp,
        current_account
      ),
    
    use = "pairwise.complete.obs"
    
  )
  
)

############################################################
# 7. FACTOR DE INFLACIÓN DE VARIANZA (VIF)
############################################################

library(car)

cat("\n==============================\n")
cat("FACTOR DE INFLACIÓN DE VARIANZA (VIF)\n")
cat("==============================\n")

modelo_vif <- lm(
  empi ~ empi_l1 + L1_rent +
    current_account + ln_gdp +
    openness + fiscal_primario +
    brecha_anual,
  data = df_panel
)

print(car::vif(modelo_vif))

############################################################
# 8. LP BOOSTRAP IRF JORDA
############################################################

library(dplyr)
library(plm)
library(purrr)

# =========================================================
# 0. SETUP
# =========================================================

horizons <- 0:5

# aseguramos orden panel correcto UNA sola vez
df_panel <- df_panel %>%
  arrange(iso3c, year)

# =========================================================
# 1. ESTIMACIÓN LOCAL PROJECTIONS
# =========================================================

results <- map(horizons, function(h){
  
  df_h <- df_panel %>%
    group_by(iso3c) %>%
    mutate(
      # DEPENDIENTE A HORIZONTE h (CORRECTO)
      dep_h = dplyr::lead(empi, h)
    ) %>%
    ungroup()
  
  plm(
    dep_h ~ L1_rent * stress_high + ln_gdp + openness,
    data = df_h,
    model = "within",
    effect = "twoways"
  )
})

# =========================================================
# 2. EXTRAER COEFICIENTES (IRFs)
# =========================================================

beta_normal <- sapply(results, function(m) {
  coef(m)["L1_rent"]
})

beta_stress <- sapply(results, function(m) {
  # si no existe interacción en algún modelo, devuelve 0
  if ("L1_rent:stress_high" %in% names(coef(m))) {
    coef(m)["L1_rent:stress_high"]
  } else {
    0
  }
})

irf_normal <- beta_normal
irf_stress <- beta_normal + beta_stress

# =========================================================
# 3. DATAFRAME IRFs
# =========================================================

irf_df <- data.frame(
  horizon = horizons,
  normal = irf_normal,
  stress = irf_stress
)

print(irf_df)

# =========================================================
# 4. GRÁFICO IRF (BASE R, SIN DEPENDENCIAS)
# =========================================================

plot(
  irf_df$horizon,
  irf_df$normal,
  type = "l",
  lwd = 2,
  col = "blue",
  ylim = range(c(irf_df$normal, irf_df$stress)),
  xlab = "Horizon (h)",
  ylab = "Effect of L1_rent on EMPI",
  main = "Local Projections: State-Dependent IRF"
)

lines(irf_df$horizon, irf_df$stress, lwd = 2, col = "red")

legend(
  "topright",
  legend = c("Normal", "Stress"),
  col = c("blue", "red"),
  lty = 1,
  lwd = 2
)

library(dplyr)
library(plm)
library(purrr)

set.seed(123)

horizons <- 0:5
B <- 200  # podés subir a 500 si querés más estabilidad

countries <- unique(df_panel$iso3c)

# =========================================================
# BOOTSTRAP FUNCTION
# =========================================================

boot_irf <- function(b){
  
  # resample países con reemplazo
  sampled_countries <- sample(countries, length(countries), replace = TRUE)
  
  df_b <- df_panel %>%
    filter(iso3c %in% sampled_countries) %>%
    mutate(id_boot = iso3c) %>%
    arrange(id_boot, year)
  
  irf_b <- map(horizons, function(h){
    
    df_h <- df_b %>%
      group_by(id_boot) %>%
      mutate(dep_h = dplyr::lead(empi, h)) %>%
      ungroup()
    
    m <- plm(
      dep_h ~ L1_rent * stress_high + ln_gdp + openness,
      data = df_h,
      model = "within",
      effect = "twoways"
    )
    
    c(
      coef(m)["L1_rent"],
      ifelse("L1_rent:stress_high" %in% names(coef(m)),
             coef(m)["L1_rent:stress_high"], 0)
    )
  })
  
  do.call(rbind, irf_b)
}

# =========================================================
# RUN BOOTSTRAP
# =========================================================

boot_results <- replicate(B, boot_irf(), simplify = FALSE)

boot_array <- array(unlist(boot_results),
                    dim = c(2, length(horizons), B))

# =========================================================
# MEAN IRF + CI
# =========================================================

irf_mean <- apply(boot_array[1,,], 1, mean)
irf_stress_mean <- apply(boot_array[1,,] + boot_array[2,,], 1, mean)

irf_ci_low <- apply(boot_array[1,,], 1, quantile, 0.05)
irf_ci_high <- apply(boot_array[1,,], 1, quantile, 0.95)

irf_stress_low <- apply(boot_array[1,,] + boot_array[2,,], 1, quantile, 0.05)
irf_stress_high <- apply(boot_array[1,,] + boot_array[2,,], 1, quantile, 0.95)

irf_df <- data.frame(
  h = horizons,
  normal = irf_mean,
  normal_low = irf_ci_low,
  normal_high = irf_ci_high,
  stress = irf_stress_mean,
  stress_low = irf_stress_low,
  stress_high = irf_stress_high
)

print(irf_df)

df_lp <- df_panel %>%
  arrange(iso3c, year)

results_jorda <- map(horizons, function(h){
  
  df_h <- df_lp %>%
    group_by(iso3c) %>%
    mutate(dep_h = dplyr::lead(empi, h)) %>%
    ungroup()
  
  plm(
    dep_h ~ L1_rent * stress_high +
      L1_rent * post2011 +
      ln_gdp + openness,
    data = df_h,
    model = "within",
    effect = "twoways"
  )
})
coef_matrix <- sapply(results, function(m) {
  c(
    rent = coef(m)["L1_rent"],
    stress = ifelse("L1_rent:stress_high" %in% names(coef(m)),
                    coef(m)["L1_rent:stress_high"], 0)
  )
})

t(coef_matrix)

plot(irf_df$h, irf_df$normal,
     type = "l", lwd = 2, col = "blue",
     ylim = range(irf_df[,2:7], na.rm = TRUE),
     xlab = "Horizon (h)",
     ylab = "Effect of rentability shock",
     main = "State-dependent IRF (Local Projections)")

# banda normal
polygon(c(irf_df$h, rev(irf_df$h)),
        c(irf_df$normal_low, rev(irf_df$normal_high)),
        col = rgb(0,0,1,0.15), border = NA)

lines(irf_df$h, irf_df$normal, col = "blue", lwd = 2)

# stress
lines(irf_df$h, irf_df$stress, col = "red", lwd = 2)

polygon(c(irf_df$h, rev(irf_df$h)),
        c(irf_df$stress_low, rev(irf_df$stress_high)),
        col = rgb(1,0,0,0.15), border = NA)

legend("topright",
       legend = c("Normal", "Stress"),
       col = c("blue", "red"),
       lty = 1,
       lwd = 2)
cat("\n=========================================\n")
cat("ANÁLISIS ECONOMÉTRICO COMPLETADO\n")
cat("=========================================\n")
# ==============================================================================
# 11. SYNTHETIC CONTROL - ESTIMACIONES COMPLETAS Y ROBUSTAS (CORREGIDO)
# ==============================================================================


# 1. EJECUCIÓN DE MODELOS (Exclusión Cruzada)
model_arg_robust <- run_synth(df_synth, "empi_robust", "ARG", exclude = "NOR")
model_arg_simple <- run_synth(df_synth, "empi", "ARG", exclude = "NOR")
model_nor_robust <- run_synth(df_synth, "empi_robust", "NOR", exclude = "ARG")
model_nor_simple <- run_synth(df_synth, "empi", "NOR", exclude = "ARG")

# 2. TABLA DE VALIDACIÓN RMSPE (Impresión Automática)
tabla_rmspe <- data.frame(
  Modelo = c("EMPI Robust", "EMPI Simple"),
  RMSPE_Arg = c(get_rmspe(model_arg_robust$df_gap), get_rmspe(model_arg_simple$df_gap)),
  RMSPE_Placebo_Noruega = c(get_rmspe(model_nor_robust$df_gap), get_rmspe(model_nor_simple$df_gap))
)

cat("\n--- TABLA 1: VALIDACIÓN RMSPE (Argentina vs Placebo) ---\n")
print(tabla_rmspe)

# 3. TABLA 3: DONANTES (del modelo Simple por defecto)
ids_donantes <- model_arg_simple$dp$tag$controls.identifier
lookup <- df_synth %>% dplyr::select(unit_id, iso3c) %>% dplyr::distinct()
tabla_donantes <- data.frame(
  unit_id = ids_donantes,
  Peso = round(as.numeric(model_arg_simple$res$solution.w), 4)
) %>%
  left_join(lookup, by = "unit_id") %>%
  filter(Peso > 0.0001) %>%
  select(Pais = iso3c, Peso) %>%
  arrange(desc(Peso))

cat("\n--- TABLA 3: PONDERACIONES DEL CONTROL SINTÉTICO (Modelo Simple) ---\n")
print(tabla_donantes)

# 4. TABLA 2: BALANCE PRE-TRATAMIENTO
tabla_balance <- data.frame(
  Variable = rownames(model_arg_simple$dp$X0),
  Argentina = round(as.numeric(model_arg_simple$dp$X1), 3),
  Sintetico = round(as.numeric(model_arg_simple$dp$X0 %*% model_arg_simple$res$solution.w), 3)
)
tabla_balance$Diferencia <- round(tabla_balance$Argentina - tabla_balance$Sintetico, 3)

cat("\n--- TABLA 2: BALANCE PRE-TRATAMIENTO (2003-2010) ---\n")
print(tabla_balance)

# ==========================================================
# 5. GRÁFICOS COMPARATIVOS (ARG vs NORUEGA - ROBUSTO)
# ==========================================================

# Definimos la función de comparación visual
plot_comparison <- function(model_arg, model_plac, title_text) {
  # Creamos un dataframe unificado
  df_comp <- data.frame(
    year = model_arg$df_gap$year,
    Argentina = model_arg$df_gap$gap,
    Noruega = model_plac$df_gap$gap
  )
  
  # Gráfico 
  ggplot(df_comp, aes(x = year)) +
    geom_line(aes(y = Argentina, color = "Argentina"), size = 1) +
    geom_line(aes(y = Noruega, color = "Noruega (Placebo)"), size = 0.8, linetype = "dashed") +
    geom_hline(yintercept = 0, color = "black", alpha = 0.5) +
    geom_vline(xintercept = 2011, color = "red", linetype = "dotted", size = 0.8) +
    scale_color_manual(values = c("Argentina" = "#1E88E5", "Noruega (Placebo)" = "#757575")) +
    labs(title = title_text,
         subtitle = "Divergencia tras el shock de 2011",
         x = "Año", y = "Gap (Real - Sintético)",
         color = "Unidad") +
    theme_minimal() +
    theme(legend.position = "bottom",
          plot.title = element_text(face = "bold", size = 12),
          panel.grid.minor = element_blank())
}

# Generar y mostrar ambos gráficos
cat("\n--- GENERANDO GRÁFICOS COMPARATIVOS ARG vs PLACEBO ---\n")

g1 <- plot_comparison(model_arg_robust, model_nor_robust, "Test de Placebo: EMPI Robust")
g2 <- plot_comparison(model_arg_simple, model_nor_simple, "Test de Placebo: EMPI Simple")

# Imprimir en consola
print(g1)
print(g2)

# Función extendida para medir errores en ambos periodos
get_rmspe_full <- function(df_gap, pre_period = 2003:2010, post_period = 2011:2023) {
  
  # Error Pre (Ajuste del modelo)
  pre <- df_gap[df_gap$year %in% pre_period, ]
  rmspe_pre <- sqrt(mean((pre$real - pre$synthetic)^2, na.rm = TRUE))
  
  # Error Post (Magnitud del efecto / Desviación del contrafáctico)
  post <- df_gap[df_gap$year %in% post_period, ]
  rmspe_post <- sqrt(mean((post$real - post$synthetic)^2, na.rm = TRUE))
  
  return(c(Pre = rmspe_pre, Post = rmspe_post))
}

# Aplicar a los modelos
res_arg_rob <- get_rmspe_full(model_arg_robust$df_gap)
res_nor_rob <- get_rmspe_full(model_nor_robust$df_gap)

# Crear tabla comparativa
tabla_evolucion_error <- data.frame(
  Escenario = c("Argentina (Robust)", "Noruega Placebo (Robust)"),
  RMSPE_Pre_2011 = c(res_arg_rob[1], res_nor_rob[1]),
  RMSPE_Post_2011 = c(res_arg_rob[2], res_nor_rob[2])
)

cat("\n--- TABLA DE EVOLUCIÓN DEL ERROR (PRE vs POST SHOCK) ---\n")
print(tabla_evolucion_error)


## ROBUSTEZ TEMPORAL 2016

library(Synth)
library(ggplot2)

run_synth_flexible <- function(df, outcome, treatment_iso3c, pre_period_range) {
  
  # 1. Identificar IDs
  tratamiento_id <- df$unit_id[df$iso3c == treatment_iso3c][1]
  donantes <- setdiff(unique(df$unit_id), tratamiento_id)
  
  # 2. Preparar datos
  dataprep_out <- dataprep(
    foo = df,
    predictors = c("ln_rentabilidad", "openness", "gdp_real", "fiscal_primario", "current_account"),
    predictors.op = "mean",
    time.predictors.prior = pre_period_range,
    special.predictors = list(list("empi", pre_period_range, "mean")),
    dependent = outcome,
    unit.variable = "unit_id",
    unit.names.variable = "iso3c",
    time.variable = "year",
    treatment.identifier = tratamiento_id,
    controls.identifier = donantes,
    time.optimize.ssr = pre_period_range,
    time.plot = 2003:2023
  )
  
  # 3. Estimar
  synth_out <- synth(data.prep.obj = dataprep_out)
  
  # 4. Construcción robusta del df_gap
  years <- as.numeric(rownames(dataprep_out$Y1plot))
  real <- as.numeric(dataprep_out$Y1plot)
  synthetic <- as.numeric(dataprep_out$Y0plot %*% synth_out$solution.w)
  
  df_gap <- data.frame(
    year = years,
    real = real,
    synthetic = synthetic,
    gap = real - synthetic
  )
  
  return(list(dp = dataprep_out, res = synth_out, df_gap = df_gap))
}

# --- EJECUCIÓN ---
model_arg_2011 <- run_synth_flexible(df_synth, "empi", "ARG", 2003:2010)
model_arg_2016 <- run_synth_flexible(df_synth, "empi", "ARG", 2003:2015)

# --- FUSIÓN SEGURA ---
# Usamos merge para garantizar que los años se alineen correctamente
df_robustez <- merge(
  model_arg_2011$df_gap[, c("year", "gap")], 
  model_arg_2016$df_gap[, c("year", "gap")], 
  by = "year", 
  suffixes = c("_2011", "_2016")
)

# --- GRÁFICO ---
ggplot(df_robustez, aes(x = year)) +
  geom_line(aes(y = gap_2011, color = "Shock 2011"), size = 1) +
  geom_line(aes(y = gap_2016, color = "Shock 2016"), size = 1, linetype = "dashed") +
  geom_hline(yintercept = 0, color = "black", alpha = 0.5) +
  geom_vline(xintercept = 2011, color = "red", linetype = "dotted") +
  geom_vline(xintercept = 2016, color = "orange", linetype = "dotted") +
  labs(title = "Análisis de Robustez: Shock 2011 vs 2016",
       subtitle = "Comparativa de Gaps (Real vs Sintético)",
       y = "Gap (EMPI)", x = "Año", color = "Escenario") +
  theme_minimal() +
  theme(legend.position = "bottom")